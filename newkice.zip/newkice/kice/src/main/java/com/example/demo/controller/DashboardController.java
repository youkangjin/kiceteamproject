package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.dto.RegionStatsDto;

@Controller
public class DashboardController {

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<RegionStatsDto> stats = getRegionStats();
        model.addAttribute("stats", stats);
        return "dashboard";
    }

    private List<RegionStatsDto> getRegionStats() {
        // 임시 데이터 생성
        RegionStatsDto seoul = new RegionStatsDto();
        seoul.setRegion("서울");
        seoul.setTotal(0);
        seoul.setComplete(0);
        seoul.setIncomplete(0);
        seoul.setPercentage(0.0);

        // 다른 지역도 비슷하게 설정...
        return Arrays.asList(seoul);
    }
}
