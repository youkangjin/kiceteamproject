package com.example.demo.controller;

import com.example.demo.model.GroupManagement;
import com.example.demo.service.GroupManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/groups")
public class GroupManagementController {

    @Autowired
    private GroupManagementService groupService;

    // 그룹 목록 조회
    @GetMapping
    public ResponseEntity<List<GroupManagement>> getAllGroups() {
        return ResponseEntity.ok(groupService.getAllGroups());
    }

    // 그룹 생성
    @PostMapping
    public ResponseEntity<GroupManagement> createGroup(@RequestBody GroupManagement group) {
        GroupManagement createdGroup = groupService.createGroup(group.getGroupName(), group.getDescription());
        return ResponseEntity.ok(createdGroup);
    }

    // 그룹 삭제
    @DeleteMapping("/{id}")
    public ResponseEntity<List<GroupManagement>> deleteGroup(@PathVariable Long id) {
        groupService.deleteGroup(id);
        return ResponseEntity.ok(groupService.getAllGroups()); // 삭제 후 최신 그룹 리스트 반환
    }

    // 그룹 수정
    @PutMapping("/{id}")
    public ResponseEntity<GroupManagement> updateGroup(
            @PathVariable Long id,
            @RequestBody GroupManagement updatedGroup) {
        GroupManagement updated = groupService.updateGroup(id, updatedGroup.getGroupName(), updatedGroup.getDescription());
        return ResponseEntity.ok(updated);
    }
}
