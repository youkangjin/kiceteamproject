package com.example.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RegionStatsDto {
    private String region;      // 지역명
    public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getComplete() {
		return complete;
	}
	public void setComplete(int complete) {
		this.complete = complete;
	}
	public int getIncomplete() {
		return incomplete;
	}
	public void setIncomplete(int incomplete) {
		this.incomplete = incomplete;
	}
	public int getArrival() {
		return arrival;
	}
	public void setArrival(int arrival) {
		this.arrival = arrival;
	}
	public int getDeparture() {
		return departure;
	}
	public void setDeparture(int departure) {
		this.departure = departure;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
	private int total;         // 전체
    private int complete;      // 완료
    private int incomplete;    // 미완료
    private int arrival;       // 출발
    private int departure;     // 도착
    private double percentage; // 진행률
} 