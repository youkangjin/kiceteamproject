package com.example.demo.controller;

import com.example.demo.model.GroupManagement;
import com.example.demo.service.GroupManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/sidebar/groups")
public class SidebarController {

    @Autowired
    private GroupManagementService groupService;

    @GetMapping
    public List<GroupManagement> getGroups() {
        return groupService.getAllGroups(); // 그룹 데이터를 JSON으로 반환
    }
}
