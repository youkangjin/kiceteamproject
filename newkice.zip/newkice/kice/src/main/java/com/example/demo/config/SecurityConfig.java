package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/css/**", "/js/**", "/images/**", "/webjars/**", "/login").permitAll() // 정적 리소스와 로그인 페이지 접근 허용
                .requestMatchers("/admin/**").hasRole("ADMIN") // 관리자 권한 확인
                .anyRequest().authenticated() // 나머지는 인증 필요
            )
            .formLogin(form -> form
                .loginPage("/login") // 사용자 정의 로그인 페이지
                .defaultSuccessUrl("/dashboard", true) // 로그인 성공 시 대시보드로 이동
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout") // 로그아웃 URL
                .logoutSuccessUrl("/login?logout") // 로그아웃 성공 후 리다이렉트
                .permitAll()
            )
            .exceptionHandling(ex -> ex
                .accessDeniedPage("/403") // 권한 거부 시 이동할 페이지
            )
            .rememberMe(rememberMe -> rememberMe
                .tokenValiditySeconds(14 * 24 * 60 * 60) // 14일 동안 Remember Me 기능 유지
                .key("uniqueAndSecretKey") // Remember Me 키
            )
            .csrf(csrf -> csrf // CSRF 활성화
                .ignoringRequestMatchers("/api/**") // REST API는 CSRF 예외 처리
            );

        return http.build();
    }
}
